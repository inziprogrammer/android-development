package com.iaminziprogrammer.tryyourluck.userdata;

public class UserData {
    private String cardTitle;
    private String cardData;

    public UserData(String cardTitle, String cardData) {
        this.cardTitle = cardTitle;
        this.cardData = cardData;
    }

    public String getCardTitle() {
        return cardTitle;
    }

    public void setCardTitle(String cardTitle) {
        this.cardTitle = cardTitle;
    }

    public String getCardData() {
        return cardData;
    }

    public void setCardData(String cardData) {
        this.cardData = cardData;
    }
}