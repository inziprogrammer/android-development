package com.iaminziprogrammer.tryyourluck.contacts;

public class Contact {
    private String contactName;
    private String contactNumber;
    private boolean isShared;

    public Contact(String contactName, String contactNumber, boolean isShared) {
        this.contactName = contactName;
        this.contactNumber = contactNumber;
        this.isShared = isShared;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public boolean isShared() {
        return isShared;
    }

    public void setShared(boolean shared) {
        isShared = shared;
    }
}