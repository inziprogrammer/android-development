package com.iaminziprogrammer.tryyourluck;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.tombayley.activitycircularreveal.CircularReveal;

public class HomeScreen extends AppCompatActivity {
    Button btnLoginScreen, btnSignupScreen, btnProfileScreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        btnLoginScreen = findViewById(R.id.btnLoginScreen);
        btnSignupScreen = findViewById(R.id.btnSignupScreen);
        btnProfileScreen = findViewById(R.id.btnProfileScreen);

        btnLoginScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CircularReveal.presentActivity(new CircularReveal.Builder(HomeScreen.this, btnLoginScreen, new Intent(getApplicationContext(), LoginScreen.class), 1000));
            }
        });

        btnSignupScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CircularReveal.presentActivity(new CircularReveal.Builder(HomeScreen.this, btnSignupScreen, new Intent(getApplicationContext(), SignupScreen.class), 1000));
            }
        });

        btnProfileScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CircularReveal.presentActivity(new CircularReveal.Builder(HomeScreen.this, btnSignupScreen, new Intent(getApplicationContext(), ProfileScreen.class), 1000));
            }
        });
    }
}