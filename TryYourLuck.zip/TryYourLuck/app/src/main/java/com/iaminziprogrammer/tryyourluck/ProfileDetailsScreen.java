package com.iaminziprogrammer.tryyourluck;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.iaminziprogrammer.tryyourluck.userdata.UserData;
import com.iaminziprogrammer.tryyourluck.userdata.UserDataAdapter;

import java.util.ArrayList;
import java.util.List;

public class ProfileDetailsScreen extends AppCompatActivity {
    RecyclerView recyclerView;
    UserDataAdapter adapter;
    List<UserData> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_details_screen);

        recyclerView = findViewById(R.id.recyclerView);
        list = new ArrayList<>();

        loadProfileDetails();
    }

    private void loadProfileDetails() {
        list.add(new UserData("Email", "iaminziprogrammer@gmail.com"));
        list.add(new UserData("Phone Number", "+92 3045068602"));
        list.add(new UserData("Lucky Number", "33"));
        list.add(new UserData("Tries Left", "10"));
        list.add(new UserData("Current Gold", "50"));
        list.add(new UserData("Total Tries", "100"));
        list.add(new UserData("Total Earnings", "50"));
        list.add(new UserData("Bonus Tries", "2 (Share Link +1)"));
        list.add(new UserData("Luck Percentage", "35%"));
        list.add(new UserData("Win / Lost", "10 / 90"));

        adapter = new UserDataAdapter(ProfileDetailsScreen.this, list);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}