package com.iaminziprogrammer.tryyourluck.userdata;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.iaminziprogrammer.tryyourluck.R;

import java.util.List;

public class UserDataAdapter extends RecyclerView.Adapter<UserDataAdapter.UserViewHolder> {
    Context context;
    List<UserData> dataList;

    public UserDataAdapter(Context context, List<UserData> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        view = LayoutInflater.from(context).inflate(R.layout.item_userdata, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        holder.cardProfileData.setAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_scale_animation));

        holder.cardTitle.setText(dataList.get(position).getCardTitle());
        holder.cardData.setText(dataList.get(position).getCardData());
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {
        TextView cardData, cardTitle;
        MaterialCardView cardProfileData;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);

            cardTitle = itemView.findViewById(R.id.cardTitle);
            cardData = itemView.findViewById(R.id.cardData);
            cardProfileData = itemView.findViewById(R.id.cardProfileData);
        }
    }
}