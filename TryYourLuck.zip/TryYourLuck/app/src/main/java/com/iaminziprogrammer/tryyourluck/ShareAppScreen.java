package com.iaminziprogrammer.tryyourluck;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.Toast;

import com.iaminziprogrammer.tryyourluck.contacts.Contact;
import com.iaminziprogrammer.tryyourluck.contacts.ContactAdapter;

import java.util.ArrayList;
import java.util.List;

public class ShareAppScreen extends AppCompatActivity {
    RecyclerView recyclerView2;
    ContactAdapter adapter;
    List<Contact> list;
    private static final int PERMISSION_REQUEST = 100;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_app_screen);

        recyclerView2 = findViewById(R.id.recyclerView2);
        list = new ArrayList<>();

        if (Build.VERSION.SDK_INT >= 23) {
            int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS);
            if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                loadContacts();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS}, PERMISSION_REQUEST);
            }
        } else {
            loadContacts();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadContacts();
            }
            else {
                Toast.makeText(this, "Permission Denied!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void loadContacts() {
        cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, ContactsContract.Contacts.DISPLAY_NAME + " ASC ");
        while (cursor.moveToNext()) {
            if (cursor.getString((cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))).length() >= 11) {
                String contactNumber = cursor.getString((cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))).replace(" ", "").replace("+92", "0").replaceFirst("0", "+92");
                Contact contact = new Contact(cursor.getString((cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))), contactNumber, false);
                list.add(contact);
            }
        }

        adapter = new ContactAdapter(getApplicationContext(), list);
        recyclerView2.setAdapter(adapter);
        recyclerView2.setLayoutManager(new LinearLayoutManager(this));
    }
}