package com.iaminziprogrammer.tryyourluck.userreview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.iaminziprogrammer.tryyourluck.R;

import java.util.List;

public class UserReviewAdapter extends RecyclerView.Adapter<UserReviewAdapter.UserReviewHolder> {
    Context context;
    List<UserReview> list;

    public UserReviewAdapter(Context context, List<UserReview> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public UserReviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        view = LayoutInflater.from(context).inflate(R.layout.item_userreview, parent, false);
        return new UserReviewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserReviewHolder holder, int position) {
        holder.reviewImage.setAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_transition_animation));
        holder.relativeLayout.setAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_scale_animation));

        holder.reviewTitle.setText(list.get(position).getReviewTitle());
        holder.reviewContent.setText(list.get(position).getReviewContent());
        holder.reviewDate.setText(list.get(position).getReviewDate());
        holder.reviewImage.setImageResource(list.get(position).getReviewImage());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class UserReviewHolder extends RecyclerView.ViewHolder {
        TextView reviewTitle, reviewContent, reviewDate;
        ImageView reviewImage;
        RelativeLayout relativeLayout;

        public UserReviewHolder(@NonNull View itemView) {
            super(itemView);

            reviewTitle = itemView.findViewById(R.id.reviewTitle);
            reviewContent = itemView.findViewById(R.id.reviewContent);
            reviewDate = itemView.findViewById(R.id.reviewDate);
            reviewImage = itemView.findViewById(R.id.reviewImage);
            relativeLayout = itemView.findViewById(R.id.relativeLayout);
        }
    }
}