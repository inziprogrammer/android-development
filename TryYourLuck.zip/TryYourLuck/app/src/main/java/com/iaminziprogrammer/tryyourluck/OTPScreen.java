package com.iaminziprogrammer.tryyourluck;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class OTPScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_o_t_p_screen);
    }
}