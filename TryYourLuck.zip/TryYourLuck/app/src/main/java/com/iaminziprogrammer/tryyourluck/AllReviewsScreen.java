package com.iaminziprogrammer.tryyourluck;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.iaminziprogrammer.tryyourluck.userdata.UserDataAdapter;
import com.iaminziprogrammer.tryyourluck.userreview.UserReview;
import com.iaminziprogrammer.tryyourluck.userreview.UserReviewAdapter;

import java.util.ArrayList;
import java.util.List;

public class AllReviewsScreen extends AppCompatActivity {
    RecyclerView recyclerView1;
    UserReviewAdapter adapter;
    List<UserReview> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_reviews_screen);

        recyclerView1 = findViewById(R.id.recyclerView1);
        list = new ArrayList<>();

        loadReviews();
    }

    private void loadReviews() {
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item1));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item2));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item3));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item4));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item5));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item6));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item7));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item8));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item9));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item10));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item11));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item12));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item1));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item2));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item3));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item4));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item5));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item6));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item7));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item8));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item9));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item10));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item11));
        list.add(new UserReview("Muhammad Inzmam", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enm ad minim veriam, quis nostrud exercitation ullmaco laboris nisi ut aliquip ex ea commodo consequest.", "1 January 2020", R.drawable.item12));

        adapter = new UserReviewAdapter(AllReviewsScreen.this, list);
        recyclerView1.setAdapter(adapter);
        recyclerView1.setLayoutManager(new LinearLayoutManager(this));
    }
}