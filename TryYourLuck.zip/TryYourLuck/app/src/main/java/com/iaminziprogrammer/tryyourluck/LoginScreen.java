package com.iaminziprogrammer.tryyourluck;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import dmax.dialog.SpotsDialog;

public class LoginScreen extends AppCompatActivity {
    ImageView imageButtonSignIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        imageButtonSignIn = findViewById(R.id.imageButtonSignIn);

        imageButtonSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLoadingDialog();
            }
        });
    }

    private void showLoadingDialog() {
        SpotsDialog dialog = new SpotsDialog(LoginScreen.this, R.style.Custom);
        dialog.setCancelable(false);
        dialog.show();
    }
}