package com.iaminziprogrammer.tryyourluck;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;

import com.tombayley.activitycircularreveal.CircularReveal;
import com.vaibhavlakhera.circularprogressview.CircularProgressView;

public class ProfileScreen extends AppCompatActivity implements View.OnClickListener {
    Button btnUserProfile, btnPublicReviews, btnShareApplication;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_screen);

        btnUserProfile = findViewById(R.id.btnUserProfile);
        btnPublicReviews = findViewById(R.id.btnPublicReviews);
        btnShareApplication = findViewById(R.id.btnShareApplication);

        btnUserProfile.setOnClickListener(this);
        btnPublicReviews.setOnClickListener(this);
        btnShareApplication.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnUserProfile:
                CircularReveal.presentActivity(new CircularReveal.Builder(ProfileScreen.this, btnUserProfile, new Intent(getApplicationContext(), ProfileDetailsScreen.class), 1000));
                break;

            case R.id.btnPublicReviews:
                CircularReveal.presentActivity(new CircularReveal.Builder(ProfileScreen.this, btnUserProfile, new Intent(getApplicationContext(), AllReviewsScreen.class), 1000));
                break;

            case R.id.btnShareApplication:
                CircularReveal.presentActivity(new CircularReveal.Builder(ProfileScreen.this, btnUserProfile, new Intent(getApplicationContext(), ShareAppScreen.class), 1000));
                break;
        }
    }
}